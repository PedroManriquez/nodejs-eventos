var server = require("./server.js");


server.start();